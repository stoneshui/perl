// Unpublished Work. ©Financial Industry Regulatory Authority, Inc.
/******************************************************************************
* Function: 
*  JSetAndSub
* 
* Purpose:
*  This function will save 2 form variables before submiting the page.  it is
*      used to pass in query parameters to the VB Com layer instead of using the
*			 querystring attribute of the request object.
*
******************************************************************************/
		function JSetAndSub(val1, val2, val3, val4)
		{
			document.Content.action = val1;
			document.Content.ORG_PK.value = val2;
			document.Content.STATE_CD.value = val3;
			// SCR#: 37205 - Start Added TOTAL_DRPS
			document.Content.TOTAL_DRPS.value = val4;
			// SCR#: 37205 - End
			document.Content.submit()
		}
		
		
		function JSub(val1)
		{
			document.Content.action = val1;
			document.Content.submit();

		}
		
		
/******************************************************************************
* Function: 
*  JNavigate
* 
* Purpose:
*  This function will verify the page is done loading before navigation is
*  allowed.*
******************************************************************************/
function JNavigate(strHref)
{

	// If the page is not done loading, just set the window to the new location
	if (bDoneLoading == "N")
	{
		window.location = strHref; 
		return;
	}
	
		window.location = strHref;
} 
