// Unpublished Work. ©Financial Industry Regulatory Authority, Inc.

function JOpenInstructionWindow(strLinkPage){

 window.open(strLinkPage,'Instruction', 'toolbar=no,location=no,directories=no,'
 + 'status=no,menubar=no,scrollbars,resizable,width=450,height=600');
 return;
 
}

function JOpenPrintWindow(sPage)
{
	var sURL;

	sURL = sPage;

	window.open(sURL,'Print','toolbar=yes,location=no,directories=no,status=no,menubar=no,scrollbars,resizable,width=640,height=600,top=0,left=0');
	return;
}

function JOpenPrintFriendlyWindow(strLinkPage){

	var sHTML = "";
	var sData = "";
	var newWindow = null;

	sData = document.getElementById("CONTENT").innerHTML;

	newWindow = window.open("",null,"top=0,left=0,height=500,width=500,status=no,toolbar=no,menubar=yes,location=no,scrollbars=yes");

	var oNewDoc = newWindow.document;

    	oNewDoc.open("text/html", "replace");

	sHTML =
	        "<HTML><HEAD>" +
	        "<SCRIPT language=\'JavaScript\'>" +
	        "function printPage(){window.print();}" +
	        "<\/SCRIPT><link REL=\'stylesheet\' HREF=\'\/Iapd\/Stylesheets\/iapd_print.css\' TYPE=\'text\/css\'><\/HEAD>" +
			"<BODY onblur=\"window.close();\" onload=\"printPage()\">" + sData +
	        "<\/BODY><\/HTML>";

	oNewDoc.writeln(sHTML);
    	oNewDoc.close();
 
}


function JOpenViewWindow(strLinkPage){

 var sURL;
 var nWidth;
 var nHeight;
 var sOptions;
 var sPosition;
 var nCharPos;

 sURL = strLinkPage;

 nWidth = screen.width * .65;
 nHeight = screen.height * .65;

 // Set the Height and Width
 sOptions = 'scrollbars, menubar=yes, locationbar, toolbar=yes,resizable, height=' + nHeight + ',width=' + nWidth;

 // Set the Top and Left
 sPosition = ',top=0,left=0';

 sOptions = sOptions + sPosition
 window.open(sURL, "View", sOptions);
 
}


function JOpenHelpWindow(strLinkPage)
{
 window.open(strLinkPage,'Help', 'toolbar=no,location=no,directories=no,'
 + 'status=no,menubar=no,scrollbars,resizable,width=450,height=600');
 return;
}


function CheckAllStates() {
// This function is used to set all email checkboxes to checked
// when the user clicks on the icon to email all users.

	var aryStates = document.forms.Content.elements["chkStates"]
	if (aryStates != null){
		nLength = aryStates.length;

		for (i = 0; i <= nLength; i++) {
		   if (aryStates[i] != null)
		      aryStates[i].checked = true;
		}
	}
}


//SCR#: 37205 - Start
function JOpenPrintAllPagesWindow(sHREF)
{
	// This function is used to calculate the number of minutes to generate
	// view all pages information.

	var sQS  = document.forms.Content.elements["PrtVwAllPages"].value;
	var sURL = sHREF + sQS;
	var sTotalDRPS = document.forms.Content.elements["TOTAL_DRPS"].value;
	// The average number of affiliates/8kb line = 28/8 = 3.5 (rounded to 4).
	var iAffiliates = 4;
	// Instead of using 56kb line, we'll use 8kb line to perform the calculations instead.	
	var iLineSize = 8;
	// This is the max file size of DRPs file.
	var iDRPFileSize = 24;	
	// This is the size of file without DRPS.
	var iNoDRPS = 182;
	var iSecToMins = 60;
	var iTotalMins;
	var iTotalSecs;
	var sConfirmStr;
	
	
	iTotalSecs = Math.round(((sTotalDRPS * iDRPFileSize) + iNoDRPS) / iLineSize)
	iTotalMins = Math.round((iTotalSecs + iAffiliates) / iSecToMins)
	if (iTotalMins == 0) iTotalMins = 1;

	if (iTotalMins > 1)
	{
		sConfirmStr = "This function could take up to " + iTotalMins + " minutes on a 56kb line.  Do you wish to continue? \n";	
	}
	else
	{
		sConfirmStr = "This function could take up to " + iTotalMins + " minute on a 56kb line.  Do you wish to continue? \n";		
	}

	sConfirmStr = sConfirmStr + "Note:  The form will be presented in a printer-friendly format.  Please wait until the entire form is ";
	sConfirmStr = sConfirmStr + "loaded before selecting the print option from your browser.";
	
	if (window.confirm(sConfirmStr))
	{
		window.open(sURL, 'Print','toolbar=yes,location=no,directories=no,status=no,menubar=no,scrollbars,resizable,width=640,height=600,top=0,left=0');
		return;
	}
}
//SCR#: 37205 - End 

